package ru.gb.androidone.donspb.enote;

import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import ru.gb.androidone.donspb.enote.EnoteData;

public class EnotesFragment extends Fragment {

    private static final String ARG_INDEX_NAME = "index";

    public EnotesFragment() {
    }

    public static EnotesFragment newInstance(String param1, String param2) {
        EnotesFragment fragment = new EnotesFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        ViewGroup view = (ViewGroup) inflater.inflate(R.layout.fragment_enotes, container, false);
        loadData(view);
        return view;
    }

    private void loadData(ViewGroup view) {
        String[] titles = getResources().getStringArray(R.array.notes_titles);
        String[] descr = getResources().getStringArray(R.array.notes_descriptions);
        String[] datan = getResources().getStringArray(R.array.notes_dates);
        int[] ids = getResources().getIntArray(R.array.notes_ids);

        for (int i = 0; i < titles.length; i++) {
            TextView tv = new TextView(getContext());
            tv.setText(titles[i]);
            tv.setTextSize(30);
            view.addView(tv);
            int ti = i;
            tv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    makeIntent(ti);
                }
            });
        }
    }

    private void makeIntent(int index) {
        Intent intent = new Intent();
        intent.setClass(getActivity(), OneNoteActivity.class);
        intent.putExtra(ARG_INDEX_NAME, index);
    }
}