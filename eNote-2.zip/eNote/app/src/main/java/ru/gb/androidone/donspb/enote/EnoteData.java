package ru.gb.androidone.donspb.enote;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class EnoteData {

    private String mNoteTitle;
    private String mNoteDescription;
    private String mDateTime;

    public String getNoteTitle() {
        return mNoteTitle;
    }

    public void setNoteTitle(String mNoteTitle) {
        this.mNoteTitle = mNoteTitle;
    }

    public String getNoteDescription() {
        return mNoteDescription;
    }

    public void setNoteDescription(String mNoteDescription) {
        this.mNoteDescription = mNoteDescription;
    }

    public String getDateTime() {
        return mDateTime.toString();
    }

    public void setDateTime() {
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date date = new Date();
        mDateTime = df.format(mDateTime);
    }




}
