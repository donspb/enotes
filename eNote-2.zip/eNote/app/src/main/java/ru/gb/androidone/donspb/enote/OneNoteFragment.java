package ru.gb.androidone.donspb.enote;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

public class OneNoteFragment extends Fragment {

    private static final String ARG_INDEX_NAME = "index";
    private int indx;

    public OneNoteFragment() {
        // Required empty public constructor
    }

    public static OneNoteFragment newInstance(int param1) {
        OneNoteFragment fragment = new OneNoteFragment();
        Bundle args = new Bundle();
        args.putInt(ARG_INDEX_NAME, param1);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            indx = getArguments().getInt(ARG_INDEX_NAME);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        String[] titles = getResources().getStringArray(R.array.notes_titles);
        String[] descr = getResources().getStringArray(R.array.notes_descriptions);
        String[] datan = getResources().getStringArray(R.array.notes_dates);

        ViewGroup view = (ViewGroup) inflater.inflate(R.layout.fragment_one_note, container, false);

        TextView tv = new TextView(getContext());
        tv.setText(titles[indx]);
        tv.setTextSize(30);
        view.addView(tv);

        tv = new TextView(getContext());
        tv.setText(descr[indx]);
        tv.setTextSize(20);
        view.addView(view);

        tv = new TextView(getContext());
        tv.setText(datan[indx]);
        tv.setTextSize(10);
        view.addView(view);

        return view;
    }
}